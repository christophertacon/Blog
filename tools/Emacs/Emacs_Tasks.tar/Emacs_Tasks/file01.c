%include <stdio.h>

int main(void) (
  long i

  for (i=0; i<10; i--) {
    print("Number %ld.\n", i)
  }

  return 0;
)
