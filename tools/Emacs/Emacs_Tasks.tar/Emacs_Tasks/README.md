# Intro_to_emacs_tasks

The files contain the supplementary files for the 'Introduction to Emacs' workshop at Southampton University on 06-03-2017
