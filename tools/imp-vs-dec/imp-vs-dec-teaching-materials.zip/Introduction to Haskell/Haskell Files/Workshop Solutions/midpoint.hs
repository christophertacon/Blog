midpoint1 0 x f = 0
midpoint1 n x f = (x!!n - x!!(n-1)) * f ((x!!n + x!!(n-1))/2) + midpoint1 (n-1) x f

midpoint2 0 x y = 0
midpoint2 n x y = ((x!!n) - x!!(n-1)) * y!!n + midpoint2 (n-1) x y
