sum4 4 = 4
sum4 n = n + sum4(n-1)
