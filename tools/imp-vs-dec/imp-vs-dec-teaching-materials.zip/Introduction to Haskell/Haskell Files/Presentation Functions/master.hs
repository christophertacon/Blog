double x = 2*x

factorial 0 = 1
factorial n = n * factorial(n-1)

fib 0 = 0
fib 1 = 1
fib n = fib(n-1) + fib(n-2)

minus x = x - 10

g x = map (minus) x
