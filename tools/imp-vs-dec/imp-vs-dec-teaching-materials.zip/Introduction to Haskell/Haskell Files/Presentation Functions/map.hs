minus x = x - 10

g x = map (minus) x
