double x = 2*x
