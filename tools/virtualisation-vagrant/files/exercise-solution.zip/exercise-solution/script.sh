#!/bin/sh

echo "vagrant test";