#!/bin/sh

sudo apt-get update -y
sudo apt-get install build-essential make -y


echo "Downloading openmpi-1.8.3.tar.gz"
wget https://www.open-mpi.org/software/ompi/v1.8/downloads/openmpi-1.8.3.tar.gz --no-check-certificate

echo "Extracting openmpi-1.8.3.tar.gz"
tar -xvf openmpi-1.8.3.tar.gz

mkdir /home/vagrant/openmpi

cd openmpi-1.8.3
echo "Configuring .openmpi"
./configure --prefix="/home/vagrant/openmpi"

echo "make"
make
echo "sudo making"
sudo make install

#Add path to both .bashrc for interactive sessions and .profile for ssh sessions
echo export PATH="$PATH:/home/vagrant/openmpi/bin" >> /home/vagrant/.bashrc
echo export LD_LIBRARY_PATH="$LD_LIBRARY_PATH:/home/vagrant/openmpi/lib/" >> /home/vagrant/.bashrc
echo export PATH="$PATH:/home/vagrant/openmpi/bin" >> /home/vagrant/.profile
echo export LD_LIBRARY_PATH="$LD_LIBRARY_PATH:/home/vagrant/openmpi/lib/" >> /home/vagrant/.profile

