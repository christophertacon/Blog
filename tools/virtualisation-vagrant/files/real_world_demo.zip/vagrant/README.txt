The development environment can be used by executing the following commands:

vagrant up #Starts the vagrant machine and automatically provisions it
vagrant ssh -c "/vagrant/run_mpi.sh" #Compiles and executes the file 'hello.c'

run_mpi can be modified to include other file that need to be run
