#!/bin/sh

cd /vagrant

echo "Compiling MPI Program"
mpicc -o hello hello.c

echo "Running MPI Program"
mpiexec -n 3 ./hello


