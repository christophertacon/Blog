Might be good to have a readme file after all.
