def hello(msg):
   """Prints Hello World + msg"""
   print("Hello World: %s!." % msg)

# this is the main program
hello("from hello.py")
