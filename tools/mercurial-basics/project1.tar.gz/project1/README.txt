The hello.py program prints a friendly message.
