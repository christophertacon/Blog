def hello(msg):
	print "Hello World: %s" % msg

hello("from hello.py")
